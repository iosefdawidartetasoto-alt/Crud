// js/modules/auth.js
const SESSION_KEY = 'rb_session';

export const auth = {
  setSession(user) {
    localStorage.setItem(SESSION_KEY, JSON.stringify(user));
  },

  getSession() {
    const raw = localStorage.getItem(SESSION_KEY);
    return raw ? JSON.parse(raw) : null;
  },

  clearSession() {
    localStorage.removeItem(SESSION_KEY);
  },

  isLoggedIn() {
    return !!this.getSession();
  },

  isAdmin() {
    const s = this.getSession();
    return s && s.role === 'admin';
  },

  isUser() {
    const s = this.getSession();
    return s && s.role === 'user';
  },
};
