// js/modules/api.js
const BASE_URL = 'http://localhost:3000';

async function request(endpoint, options = {}) {
  const res = await fetch(`${BASE_URL}${endpoint}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  if (!res.ok) throw new Error(`HTTP error ${res.status}`);
  if (res.status === 204) return null;
  return res.json();
}

export const api = {
  // Users
  getUsers: () => request('/users'),
  getUserByEmail: (email) => request(`/users?email=${encodeURIComponent(email)}`),

  // Spaces
  getSpaces: () => request('/spaces'),
  getSpaceById: (id) => request(`/spaces/${id}`),
  createSpace: (data) => request('/spaces', { method: 'POST', body: JSON.stringify(data) }),
  updateSpace: (id, data) => request(`/spaces/${id}`, { method: 'PATCH', body: JSON.stringify(data) }),
  deleteSpace: (id) => request(`/spaces/${id}`, { method: 'DELETE' }),

  // Reservations
  getReservations: () => request('/reservations'),
  getReservationById: (id) => request(`/reservations/${id}`),
  getReservationsByUser: (userId) => request(`/reservations?userId=${userId}`),
  createReservation: (data) => request('/reservations', { method: 'POST', body: JSON.stringify(data) }),
  updateReservation: (id, data) => request(`/reservations/${id}`, { method: 'PATCH', body: JSON.stringify(data) }),
  deleteReservation: (id) => request(`/reservations/${id}`, { method: 'DELETE' }),
};
