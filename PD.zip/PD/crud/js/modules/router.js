// js/modules/router.js
import { auth } from './auth.js';

const routes = {};

export const router = {
  register(name, handler) {
    routes[name] = handler;
  },

  navigate(name, params = {}) {
    // Not logged in → only login
    if (!auth.isLoggedIn() && name !== 'login') {
      this.navigate('login');
      return;
    }
    // Already logged in → skip login
    if (auth.isLoggedIn() && name === 'login') {
      this.navigate('dashboard');
      return;
    }
    // Role guard: admin-only routes
    const adminRoutes = ['admin-reservations', 'spaces'];
    if (auth.isUser() && adminRoutes.includes(name)) {
      this._showAccessDenied();
      return;
    }

    history.pushState({ name, params }, '', `#${name}`);
    this._render(name, params);
  },

  _showAccessDenied() {
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    const view = document.getElementById('denied-view');
    if (view) view.classList.add('active');
  },

  _render(name, params = {}) {
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    const handler = routes[name];
    if (handler) handler(params);
  },

  init() {
    window.addEventListener('popstate', (e) => {
      if (e.state) this._render(e.state.name, e.state.params);
    });

    const hash = window.location.hash.replace('#', '') || 'login';
    const name = auth.isLoggedIn() ? (hash === 'login' ? 'dashboard' : hash) : 'login';

    // Guard on direct hash navigation
    const adminRoutes = ['admin-reservations', 'spaces'];
    if (auth.isUser() && adminRoutes.includes(name)) {
      this._render('dashboard');
      return;
    }

    this._render(name);
  },
};
