// js/views/reservations.js
import { api } from '../modules/api.js';
import { auth } from '../modules/auth.js';
import {
  showToast, showLoader, hideLoader,
  statusBadge, formatDate, openModal, closeModal, confirmDelete,
} from '../modules/ui.js';

const PAGE_SIZE = 6;
let allReservations = [];
let allSpaces       = [];
let allUsers        = [];
let filtered        = [];
let currentPage     = 1;
let editingId       = null;
let isAdminView     = false;

// ─── ENTRY POINTS ─────────────────────────────────────────────────────────────

export async function renderAdminReservations() {
  isAdminView = true;
  await _renderReservations();
}

export async function renderMyReservations() {
  isAdminView = false;
  await _renderReservations();
}

// ─── CORE RENDER ──────────────────────────────────────────────────────────────

async function _renderReservations() {
  const view = document.getElementById('reservations-view');
  view.classList.add('active');

  document.getElementById('reservations-title').textContent =
    isAdminView ? 'All Reservations' : 'My Reservations';
  document.getElementById('reservations-subtitle').textContent =
    isAdminView ? 'Full reservation management' : 'Your active reservations and history';

  const thUser = document.getElementById('th-user');
  if (thUser) thUser.style.display = isAdminView ? '' : 'none';

  showLoader();
  try {
    [allReservations, allSpaces, allUsers] = await Promise.all([
      api.getReservations(),
      api.getSpaces(),
      api.getUsers(),
    ]);

    _populateSpaceSelect();
    applyFilters();
    _bindToolbarEvents();
    _bindModalEvents();
  } catch {
    showToast('Failed to load reservations.', 'error');
  } finally {
    hideLoader();
  }
}

// ─── FILTERS ──────────────────────────────────────────────────────────────────

function applyFilters() {
  const user    = auth.getSession();
  const search  = document.getElementById('res-search')?.value.toLowerCase() || '';
  const statusF = document.getElementById('res-status-filter')?.value || '';
  const dateF   = document.getElementById('res-date-filter')?.value || '';

  let base = isAdminView
    ? allReservations
    : allReservations.filter(r => r.userId === user.id);

  if (search) {
    base = base.filter(r => {
      const space = allSpaces.find(s => s.id === r.spaceId);
      return (
        space?.name.toLowerCase().includes(search) ||
        r.reason.toLowerCase().includes(search)
      );
    });
  }
  if (statusF) base = base.filter(r => r.status === statusF);
  if (dateF)   base = base.filter(r => r.date === dateF);

  filtered    = base;
  currentPage = 1;
  _renderTable();
}

// ─── TABLE ────────────────────────────────────────────────────────────────────

function _renderTable() {
  const user  = auth.getSession();
  const tbody = document.getElementById('reservations-tbody');
  const start = (currentPage - 1) * PAGE_SIZE;
  const page  = filtered.slice(start, start + PAGE_SIZE);

  const getSpaceName = (id) => allSpaces.find(s => s.id === id)?.name || '—';
  const getUserName  = (id) => allUsers.find(u => u.id === id)?.name  || '—';

  if (!page.length) {
    tbody.innerHTML = `<tr><td colspan="7"><div class="empty-state"><p>No reservations found.</p></div></td></tr>`;
    _renderPagination();
    return;
  }

  tbody.innerHTML = page.map(r => {
    const canEdit    = isAdminView || (r.status === 'Pending' && r.userId === user.id);
    const canDelete  = isAdminView;
    const canApprove = isAdminView && r.status === 'Pending';
    const canCancel  = !isAdminView && (r.status === 'Pending' || r.status === 'Approved') && r.userId === user.id;

    return `
      <tr>
        <td>
          <div class="project-name">${getSpaceName(r.spaceId)}</div>
          <div class="project-desc">${r.reason}</div>
        </td>
        <td>${formatDate(r.date)}</td>
        <td>${r.startTime} – ${r.endTime}</td>
        ${isAdminView ? `<td class="td-user">${getUserName(r.userId)}</td>` : ''}
        <td>${statusBadge(r.status)}</td>
        <td>
          <div class="actions-cell">
            ${canEdit    ? `<button class="btn-icon edit-res-btn"    data-id="${r.id}" title="Edit">Edit</button>` : ''}
            ${canApprove ? `
              <button class="btn-icon approve-btn" data-id="${r.id}" title="Approve">Approve</button>
              <button class="btn-icon reject-btn"  data-id="${r.id}" title="Reject">Reject</button>
            ` : ''}
            ${canCancel  ? `<button class="btn-icon cancel-res-btn" data-id="${r.id}" title="Cancel">Cancel</button>` : ''}
            ${canDelete  ? `<button class="btn-icon btn-danger delete-res-btn" data-id="${r.id}" title="Delete">Delete</button>` : ''}
          </div>
        </td>
      </tr>
    `;
  }).join('');

  _renderPagination();
  _bindTableEvents();
}

function _renderPagination() {
  const container = document.getElementById('res-pagination');
  const total     = Math.ceil(filtered.length / PAGE_SIZE);
  if (total <= 1) { container.innerHTML = ''; return; }

  let html = `<button class="page-btn" id="res-prev" ${currentPage === 1 ? 'disabled' : ''}>Prev</button>`;
  for (let i = 1; i <= total; i++) {
    html += `<button class="page-btn ${i === currentPage ? 'active' : ''}" data-page="${i}">${i}</button>`;
  }
  html += `<button class="page-btn" id="res-next" ${currentPage === total ? 'disabled' : ''}>Next</button>`;
  container.innerHTML = html;

  container.querySelectorAll('[data-page]').forEach(btn =>
    btn.addEventListener('click', () => { currentPage = parseInt(btn.dataset.page); _renderTable(); })
  );
  container.querySelector('#res-prev')?.addEventListener('click', () => { currentPage--; _renderTable(); });
  container.querySelector('#res-next')?.addEventListener('click', () => { currentPage++; _renderTable(); });
}

// ─── TABLE EVENTS ─────────────────────────────────────────────────────────────

function _bindTableEvents() {
  document.querySelectorAll('.edit-res-btn').forEach(btn =>
    btn.addEventListener('click', () => _openEditModal(parseInt(btn.dataset.id)))
  );
  document.querySelectorAll('.approve-btn').forEach(btn =>
    btn.addEventListener('click', () => _changeStatus(parseInt(btn.dataset.id), 'Approved'))
  );
  document.querySelectorAll('.reject-btn').forEach(btn =>
    btn.addEventListener('click', () => _changeStatus(parseInt(btn.dataset.id), 'Rejected'))
  );
  document.querySelectorAll('.cancel-res-btn').forEach(btn =>
    btn.addEventListener('click', () => _changeStatus(parseInt(btn.dataset.id), 'Cancelled'))
  );
  document.querySelectorAll('.delete-res-btn').forEach(btn =>
    btn.addEventListener('click', () => {
      confirmDelete(async () => {
        showLoader();
        try {
          await api.deleteReservation(parseInt(btn.dataset.id));
          allReservations = allReservations.filter(r => r.id !== parseInt(btn.dataset.id));
          applyFilters();
          showToast('Reservation deleted.', 'success');
        } catch {
          showToast('Failed to delete reservation.', 'error');
        } finally { hideLoader(); }
      });
    })
  );
}

async function _changeStatus(id, newStatus) {
  showLoader();
  try {
    const updated = await api.updateReservation(id, { status: newStatus });
    const idx = allReservations.findIndex(r => r.id === id);
    if (idx > -1) allReservations[idx] = updated;
    applyFilters();
    showToast(`Reservation ${newStatus.toLowerCase()}.`, 'success');
  } catch {
    showToast('Failed to update status.', 'error');
  } finally { hideLoader(); }
}

// ─── TOOLBAR EVENTS ───────────────────────────────────────────────────────────

function _bindToolbarEvents() {
  document.getElementById('res-search')?.addEventListener('input', applyFilters);
  document.getElementById('res-status-filter')?.addEventListener('change', applyFilters);
  document.getElementById('res-date-filter')?.addEventListener('change', applyFilters);
  document.getElementById('new-res-btn')?.addEventListener('click', _openCreateModal);
}

// ─── MODAL ────────────────────────────────────────────────────────────────────

function _populateSpaceSelect(selectedId = null) {
  const sel       = document.getElementById('res-space');
  const available = allSpaces.filter(s => s.status === 'Available');
  sel.innerHTML   = `<option value="">Select a space...</option>` +
    available.map(s =>
      `<option value="${s.id}" ${s.id === selectedId ? 'selected' : ''}>${s.name} (${s.type})</option>`
    ).join('');
}

function _openCreateModal() {
  editingId = null;
  document.getElementById('res-modal-title').textContent = 'New Reservation';
  document.getElementById('res-form').reset();
  _populateSpaceSelect();
  openModal('reservation-modal');
}

function _openEditModal(id) {
  const reservation = allReservations.find(r => r.id === id);
  if (!reservation) return;

  if (!isAdminView && reservation.status !== 'Pending') {
    showToast('You can only edit pending reservations.', 'warning');
    return;
  }

  editingId = id;
  document.getElementById('res-modal-title').textContent = 'Edit Reservation';
  _populateSpaceSelect(reservation.spaceId);
  document.getElementById('res-date').value   = reservation.date;
  document.getElementById('res-start').value  = reservation.startTime;
  document.getElementById('res-end').value    = reservation.endTime;
  document.getElementById('res-reason').value = reservation.reason;
  openModal('reservation-modal');
}

function _bindModalEvents() {
  document.querySelectorAll('[data-close-modal]').forEach(btn =>
    btn.addEventListener('click', () => closeModal(btn.dataset.closeModal))
  );

  const form = document.getElementById('res-form');
  form.onsubmit = async (e) => {
    e.preventDefault();
    const user    = auth.getSession();
    const spaceId = parseInt(document.getElementById('res-space').value);
    const date    = document.getElementById('res-date').value;
    const start   = document.getElementById('res-start').value;
    const end     = document.getElementById('res-end').value;
    const reason  = document.getElementById('res-reason').value.trim();

    if (!spaceId || !date || !start || !end || !reason) {
      showToast('Please fill in all fields.', 'error');
      return;
    }
    if (start >= end) {
      showToast('Start time must be before end time.', 'error');
      return;
    }

    // Duplicate check
    const duplicate = allReservations.some(r => {
      if (editingId && r.id === editingId) return false;
      if (r.spaceId !== spaceId || r.date !== date) return false;
      if (r.status === 'Cancelled' || r.status === 'Rejected') return false;
      return !(end <= r.startTime || start >= r.endTime);
    });

    if (duplicate) {
      showToast('A reservation already exists for that space and time slot.', 'error');
      return;
    }

    const payload = { spaceId, date, startTime: start, endTime: end, reason };
    if (!editingId) {
      payload.userId = user.id;
      payload.status = 'Pending';
    }

    showLoader();
    try {
      if (editingId) {
        const updated = await api.updateReservation(editingId, payload);
        const idx = allReservations.findIndex(r => r.id === editingId);
        if (idx > -1) allReservations[idx] = updated;
        showToast('Reservation updated.', 'success');
      } else {
        const created = await api.createReservation(payload);
        allReservations.unshift(created);
        showToast('Reservation created.', 'success');
      }
      closeModal('reservation-modal');
      applyFilters();
    } catch {
      showToast('Failed to save reservation.', 'error');
    } finally { hideLoader(); }
  };
}
