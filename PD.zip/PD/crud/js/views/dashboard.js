// js/views/dashboard.js
import { api } from '../modules/api.js';
import { auth } from '../modules/auth.js';
import { showToast, hideLoader, showLoader, statusBadge, formatDate } from '../modules/ui.js';
import { router } from '../modules/router.js';

export async function renderDashboard() {
  const view = document.getElementById('dashboard-view');
  view.classList.add('active');
  const user = auth.getSession();

  showLoader();
  try {
    const [reservations, spaces, users] = await Promise.all([
      api.getReservations(),
      api.getSpaces(),
      api.getUsers(),
    ]);

    const myReservations = user.role === 'admin'
      ? reservations
      : reservations.filter(r => r.userId === user.id);

    renderStats(myReservations, spaces, user.role);
    renderRecentReservations(myReservations, spaces, users, user.role);
  } catch {
    showToast('Failed to load dashboard data.', 'error');
  } finally {
    hideLoader();
  }
}

function renderStats(reservations, spaces, role) {
  const el = document.getElementById('dashboard-stats');

  const total     = reservations.length;
  const pending   = reservations.filter(r => r.status === 'Pending').length;
  const approved  = reservations.filter(r => r.status === 'Approved').length;
  const rejected  = reservations.filter(r => r.status === 'Rejected').length;
  const cancelled = reservations.filter(r => r.status === 'Cancelled').length;
  const available = spaces.filter(s => s.status === 'Available').length;

  if (role === 'admin') {
    el.innerHTML = `
      <div class="stat-card">
        <div class="stat-value">${total}</div>
        <div class="stat-label">Total Reservations</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">${pending}</div>
        <div class="stat-label">Pending</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">${approved}</div>
        <div class="stat-label">Approved</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">${available}</div>
        <div class="stat-label">Available Spaces</div>
      </div>
    `;
  } else {
    el.innerHTML = `
      <div class="stat-card">
        <div class="stat-value">${total}</div>
        <div class="stat-label">My Reservations</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">${pending}</div>
        <div class="stat-label">Pending</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">${approved}</div>
        <div class="stat-label">Approved</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">${cancelled + rejected}</div>
        <div class="stat-label">Cancelled / Rejected</div>
      </div>
    `;
  }
}

function renderRecentReservations(reservations, spaces, users, role) {
  const container = document.getElementById('recent-reservations');
  const recent = [...reservations]
    .sort((a, b) => new Date(b.date) - new Date(a.date))
    .slice(0, 5);

  if (!recent.length) {
    container.innerHTML = `<div class="empty-state"><p>No reservations yet.</p></div>`;
    return;
  }

  const getSpaceName = (id) => spaces.find(s => s.id === id)?.name || '—';
  const getUserName  = (id) => users.find(u => u.id === id)?.name  || '—';

  container.innerHTML = `
    <table class="projects-table">
      <thead>
        <tr>
          <th>Space</th>
          <th>Date</th>
          <th>Time</th>
          ${role === 'admin' ? '<th>User</th>' : ''}
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        ${recent.map(r => `
          <tr>
            <td>
              <div class="project-name">${getSpaceName(r.spaceId)}</div>
              <div class="project-desc">${r.reason}</div>
            </td>
            <td>${formatDate(r.date)}</td>
            <td>${r.startTime} – ${r.endTime}</td>
            ${role === 'admin' ? `<td>${getUserName(r.userId)}</td>` : ''}
            <td>${statusBadge(r.status)}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;

  const link = document.getElementById('dashboard-see-all');
  if (link) {
    link.onclick = (e) => {
      e.preventDefault();
      router.navigate(role === 'admin' ? 'admin-reservations' : 'my-reservations');
    };
  }
}
