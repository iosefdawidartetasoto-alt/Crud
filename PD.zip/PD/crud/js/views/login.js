// js/views/login.js
import { api } from '../modules/api.js';
import { auth } from '../modules/auth.js';
import { router } from '../modules/router.js';
import { showToast, showLoader, hideLoader } from '../modules/ui.js';

export function renderLogin() {
  const view = document.getElementById('login-view');
  view.classList.add('active');

  const form = document.getElementById('login-form');
  const errorMsg = document.getElementById('login-error');

  form.reset();
  errorMsg.textContent = '';

  form.onsubmit = async (e) => {
    e.preventDefault();
    errorMsg.textContent = '';

    const email    = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;

    if (!email || !password) {
      errorMsg.textContent = 'Please fill in all fields.';
      return;
    }

    showLoader();
    try {
      const users = await api.getUserByEmail(email);
      const user  = users.find(u => u.email === email && u.password === password);

      if (!user) {
        errorMsg.textContent = 'Invalid email or password.';
        hideLoader();
        return;
      }

      auth.setSession(user);
      showToast(`Welcome back, ${user.name}!`, 'success');
      router.navigate('dashboard');
    } catch {
      errorMsg.textContent = 'Cannot connect to the server. Is json-server running?';
      showToast('Connection error. Make sure json-server is running.', 'error');
    } finally {
      hideLoader();
    }
  };
}
