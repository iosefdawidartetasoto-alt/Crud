// js/views/spaces.js  — Admin only
import { api } from '../modules/api.js';
import {
  showToast, showLoader, hideLoader,
  spaceStatusBadge, openModal, closeModal, confirmDelete,
} from '../modules/ui.js';

let allSpaces = [];
let editingId = null;

export async function renderSpaces() {
  const view = document.getElementById('spaces-view');
  view.classList.add('active');

  showLoader();
  try {
    allSpaces = await api.getSpaces();
    _renderTable();
    _bindEvents();
  } catch {
    showToast('Failed to load spaces.', 'error');
  } finally {
    hideLoader();
  }
}

function _renderTable() {
  const tbody = document.getElementById('spaces-tbody');

  if (!allSpaces.length) {
    tbody.innerHTML = `<tr><td colspan="6"><div class="empty-state"><p>No spaces registered.</p></div></td></tr>`;
    return;
  }

  tbody.innerHTML = allSpaces.map(s => `
    <tr>
      <td><div class="project-name">${s.name}</div></td>
      <td>${s.type}</td>
      <td>${s.capacity}</td>
      <td>${s.location}</td>
      <td>${spaceStatusBadge(s.status)}</td>
      <td>
        <div class="actions-cell">
          <button class="btn-icon edit-space-btn"              data-id="${s.id}" title="Edit">Edit</button>
          <button class="btn-icon btn-danger delete-space-btn" data-id="${s.id}" title="Delete">Delete</button>
        </div>
      </td>
    </tr>
  `).join('');

  document.querySelectorAll('.edit-space-btn').forEach(btn =>
    btn.addEventListener('click', () => _openEditModal(parseInt(btn.dataset.id)))
  );
  document.querySelectorAll('.delete-space-btn').forEach(btn =>
    btn.addEventListener('click', () => {
      confirmDelete(async () => {
        showLoader();
        try {
          await api.deleteSpace(parseInt(btn.dataset.id));
          allSpaces = allSpaces.filter(s => s.id !== parseInt(btn.dataset.id));
          _renderTable();
          showToast('Space deleted.', 'success');
        } catch {
          showToast('Failed to delete space.', 'error');
        } finally { hideLoader(); }
      });
    })
  );
}

function _bindEvents() {
  document.getElementById('new-space-btn')?.addEventListener('click', _openCreateModal);

  document.querySelectorAll('[data-close-modal]').forEach(btn =>
    btn.addEventListener('click', () => closeModal(btn.dataset.closeModal))
  );

  document.getElementById('space-form').onsubmit = async (e) => {
    e.preventDefault();
    const name     = document.getElementById('sp-name').value.trim();
    const type     = document.getElementById('sp-type').value;
    const capacity = parseInt(document.getElementById('sp-capacity').value);
    const location = document.getElementById('sp-location').value.trim();
    const status   = document.getElementById('sp-status').value;

    if (!name || !type || !capacity || !location) {
      showToast('Please fill in all fields.', 'error');
      return;
    }

    const payload = { name, type, capacity, location, status };

    showLoader();
    try {
      if (editingId) {
        const updated = await api.updateSpace(editingId, payload);
        const idx = allSpaces.findIndex(s => s.id === editingId);
        if (idx > -1) allSpaces[idx] = updated;
        showToast('Space updated.', 'success');
      } else {
        const created = await api.createSpace(payload);
        allSpaces.push(created);
        showToast('Space created.', 'success');
      }
      closeModal('space-modal');
      _renderTable();
    } catch {
      showToast('Failed to save space.', 'error');
    } finally { hideLoader(); }
  };
}

function _openCreateModal() {
  editingId = null;
  document.getElementById('space-modal-title').textContent = 'New Space';
  document.getElementById('space-form').reset();
  openModal('space-modal');
}

function _openEditModal(id) {
  const space = allSpaces.find(s => s.id === id);
  if (!space) return;
  editingId = id;
  document.getElementById('space-modal-title').textContent = 'Edit Space';
  document.getElementById('sp-name').value     = space.name;
  document.getElementById('sp-type').value     = space.type;
  document.getElementById('sp-capacity').value = space.capacity;
  document.getElementById('sp-location').value = space.location;
  document.getElementById('sp-status').value   = space.status;
  openModal('space-modal');
}
