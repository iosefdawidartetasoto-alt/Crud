// js/app.js
import { router } from './modules/router.js';
import { auth } from './modules/auth.js';
import { showToast } from './modules/ui.js';
import { renderLogin } from './views/login.js';
import { renderDashboard } from './views/dashboard.js';
import { renderAdminReservations, renderMyReservations } from './views/reservations.js';
import { renderSpaces } from './views/spaces.js';

// === THEME ===
const savedTheme = localStorage.getItem('theme') || 'dark';
document.documentElement.setAttribute('data-theme', savedTheme);
document.getElementById('theme-toggle').textContent = savedTheme === 'dark' ? '☀️' : '🌙';

document.getElementById('theme-toggle').addEventListener('click', () => {
  const current = document.documentElement.getAttribute('data-theme');
  const next = current === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem('theme', next);
  document.getElementById('theme-toggle').textContent = next === 'dark' ? '☀️' : '🌙';
});

// === NAVBAR ===
function updateNavbar() {
  const user   = auth.getSession();
  const navbar = document.getElementById('app-navbar');
  if (!user) { navbar.style.display = 'none'; return; }
  navbar.style.display = 'flex';

  const initials = user.name.split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase();
  document.getElementById('nav-avatar').textContent    = initials;
  document.getElementById('nav-username').textContent  = user.name;
  document.getElementById('nav-role').textContent      = user.role;
  document.getElementById('nav-role-badge').textContent = user.role;
  document.getElementById('nav-role-badge').className   = `role-badge ${user.role}`;

  document.querySelectorAll('[data-admin-only]').forEach(
    el => (el.style.display = user.role === 'admin' ? '' : 'none')
  );
  document.querySelectorAll('[data-user-only]').forEach(
    el => (el.style.display = user.role === 'user' ? '' : 'none')
  );
}

// === NAV LINKS ===
document.getElementById('nav-dashboard').addEventListener('click', (e) => {
  e.preventDefault(); router.navigate('dashboard');
});
document.getElementById('nav-admin-reservations').addEventListener('click', (e) => {
  e.preventDefault(); router.navigate('admin-reservations');
});
document.getElementById('nav-my-reservations').addEventListener('click', (e) => {
  e.preventDefault(); router.navigate('my-reservations');
});
document.getElementById('nav-spaces').addEventListener('click', (e) => {
  e.preventDefault(); router.navigate('spaces');
});
document.getElementById('logout-btn').addEventListener('click', () => {
  auth.clearSession();
  showToast('You have been logged out.', 'info');
  router.navigate('login');
  updateNavbar();
});

// === REGISTER ROUTES ===
router.register('login', () => {
  updateNavbar();
  renderLogin();
});
router.register('dashboard', () => {
  updateNavbar();
  renderDashboard();
});
router.register('admin-reservations', () => {
  updateNavbar();
  renderAdminReservations();
});
router.register('my-reservations', () => {
  updateNavbar();
  renderMyReservations();
});
router.register('spaces', () => {
  updateNavbar();
  renderSpaces();
});

// === INIT ===
router.init();
