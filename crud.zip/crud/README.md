# ProjectHub — Internal Project Management SPA

## Description
A Single Page Application (SPA) for managing internal company projects. Built with Vanilla JavaScript (ES Modules), it features role-based access control, session persistence, and a simulated REST API via json-server.

## Technologies
- **Vanilla JavaScript** (ES Modules, no frameworks)
- **HTML5 / CSS3** (custom properties, CSS Grid, Flexbox)
- **json-server** — simulated REST API
- **localStorage** — session persistence
- **Google Fonts** — Syne + DM Sans

## Installation

Make sure you have **Node.js** installed (v14+).

```bash
# 1. Enter the project folder
cd crud

# 2. Install json-server globally (only once)
npm install -g json-server
```

## Running the Project

You need **two terminals** open simultaneously.

### Terminal 1 — Start the API (json-server)
```bash
cd crud
json-server --watch db.json --port 3000
```
The API will be available at: `http://localhost:3000`

### Terminal 2 — Serve the frontend
```bash
# Option A: Using npx serve (recommended)
npx serve .

# Option B: Using Python
python3 -m http.server 8080

# Option C: VS Code Live Server extension
# Right-click index.html → Open with Live Server
```
Then open your browser at: `http://localhost:3000` (serve) or `http://localhost:8080` (python)

> ⚠️ **Important:** You MUST serve the files through a local server (not by opening index.html directly as a file) because ES Modules require HTTP.

## Running JSON Server

```bash
json-server --watch db.json --port 3000
```

Available endpoints:
- `GET/POST /projects`
- `GET/PATCH/DELETE /projects/:id`
- `GET /users`
- `GET /users?email=...`

## Test Users

| Role         | Email              | Password |
|--------------|--------------------|----------|
| Manager      | manager@test.com   | 123456   |
| Collaborator | user@test.com      | 123456   |
| Collaborator | maria@test.com     | 123456   |

## Project Structure

```
crud/
├── index.html              # SPA shell (single HTML file)
├── db.json                 # json-server database
├── css/
│   └── styles.css          # All styles (dark/light theme, components)
├── js/
│   ├── app.js              # Entry point, router registration, navbar
│   ├── modules/
│   │   ├── api.js          # All fetch calls to json-server
│   │   ├── auth.js         # Session management (localStorage)
│   │   ├── router.js       # Client-side SPA router
│   │   └── ui.js           # Toast, loader, modal helpers
│   └── views/
│       ├── login.js        # Login form logic
│       ├── dashboard.js    # Stats + recent projects
│       ├── projects.js     # Full CRUD table + modals
│       └── detail.js       # Single project detail
└── README.md
```

## Role Permissions

| Feature                    | Manager | Collaborator |
|----------------------------|---------|--------------|
| View all projects          | ✅      | ❌           |
| View assigned projects     | ✅      | ✅           |
| Create projects            | ✅      | ❌           |
| Edit projects (full)       | ✅      | ❌           |
| Update own project status  | ✅      | ✅           |
| Delete projects            | ✅      | ❌           |
| View project details       | ✅      | ✅ (own only)|
| Dashboard stats (all)      | ✅      | ❌           |
| Dashboard stats (own)      | ✅      | ✅           |

## Technical Decisions

- **ES Modules** over bundlers: keeps the stack zero-config while enforcing proper code separation.
- **localStorage** for session: persists across browser restarts, matching the "open browser again" requirement.
- **Hash-based routing** (`#dashboard`, `#projects`): no server config needed, works with any static host.
- **Single HTML file shell**: all views are pre-rendered HTML sections toggled with CSS `.active` class. No innerHTML injection for the shell — only dynamic data is injected via JS.
- **Modular architecture**: `modules/` for shared logic, `views/` for page renderers — easy to scale.
- **Optimistic UI**: table updates immediately after API success, no full re-fetch required.
- **Dark / Light theme**: CSS custom properties + `data-theme` attribute, preference saved to localStorage.

## Bonus Features Implemented
- ✅ Dark Mode toggle
- ✅ Search by name/description
- ✅ Filter by status
- ✅ Pagination (6 items per page)
- ✅ Toast notifications
- ✅ Loading spinner
- ✅ Confirm dialog for deletes
- ✅ Responsive design (mobile-friendly)
