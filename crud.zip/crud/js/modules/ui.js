// js/modules/ui.js

// === TOAST ===
export function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  const icons = { success: '✅', error: '❌', info: 'ℹ️' };
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span class="toast-icon">${icons[type] || 'ℹ️'}</span><span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => {
    toast.classList.add('removing');
    toast.addEventListener('animationend', () => toast.remove());
  }, 3200);
}

// === LOADER ===
export function showLoader() { document.getElementById('loader').classList.add('active'); }
export function hideLoader() { document.getElementById('loader').classList.remove('active'); }

// === MODAL ===
export function openModal(id) { document.getElementById(id).classList.add('open'); }
export function closeModal(id) { document.getElementById(id).classList.remove('open'); }

// === STATUS BADGE ===
export function statusBadge(status) {
  const map = {
    'Pending': 'status-pending',
    'In Progress': 'status-in-progress',
    'Completed': 'status-completed',
    'Cancelled': 'status-cancelled',
  };
  const cls = map[status] || 'status-pending';
  return `<span class="status-badge ${cls}">${status}</span>`;
}

// === AVATAR INITIALS ===
export function avatarInitials(name = '') {
  return name.split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase();
}

// === FORMAT DATE ===
export function formatDate(dateStr) {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

// === CONFIRM DIALOG ===
export function confirmDelete(onConfirm) {
  const overlay = document.getElementById('confirm-modal');
  overlay.classList.add('open');
  document.getElementById('confirm-ok').onclick = () => {
    overlay.classList.remove('open');
    onConfirm();
  };
  document.getElementById('confirm-cancel').onclick = () => overlay.classList.remove('open');
}
