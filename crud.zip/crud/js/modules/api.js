// js/modules/api.js
const BASE_URL = 'http://localhost:3000';

async function request(endpoint, options = {}) {
  const res = await fetch(`${BASE_URL}${endpoint}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  if (!res.ok) throw new Error(`HTTP error ${res.status}`);
  if (res.status === 204) return null;
  return res.json();
}

export const api = {
  // Users
  getUsers: () => request('/users'),
  getUserByEmail: (email) => request(`/users?email=${encodeURIComponent(email)}`),

  // Projects
  getProjects: () => request('/projects'),
  getProjectById: (id) => request(`/projects/${id}`),
  createProject: (data) => request('/projects', { method: 'POST', body: JSON.stringify(data) }),
  updateProject: (id, data) => request(`/projects/${id}`, { method: 'PATCH', body: JSON.stringify(data) }),
  deleteProject: (id) => request(`/projects/${id}`, { method: 'DELETE' }),
};
