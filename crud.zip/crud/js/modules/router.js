// js/modules/router.js
import { auth } from './auth.js';

const routes = {};

export const router = {
  register(name, handler) {
    routes[name] = handler;
  },

  navigate(name, params = {}) {
    if (!auth.isLoggedIn() && name !== 'login') {
      this.navigate('login');
      return;
    }
    if (auth.isLoggedIn() && name === 'login') {
      this.navigate('dashboard');
      return;
    }
    // Role protection: collaborators can't access manager-only views
    if (auth.isCollaborator() && name === 'projects' && params.adminOnly) {
      this.navigate('dashboard');
      return;
    }

    history.pushState({ name, params }, '', `#${name}`);
    this._render(name, params);
  },

  _render(name, params = {}) {
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    const handler = routes[name];
    if (handler) handler(params);
  },

  init() {
    window.addEventListener('popstate', (e) => {
      if (e.state) this._render(e.state.name, e.state.params);
    });

    const hash = window.location.hash.replace('#', '') || 'login';
    const name = auth.isLoggedIn() ? (hash === 'login' ? 'dashboard' : hash) : 'login';
    this._render(name);
  },
};
