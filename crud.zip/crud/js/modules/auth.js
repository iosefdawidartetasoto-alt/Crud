// js/modules/auth.js
const SESSION_KEY = 'pm_session';

export const auth = {
  setSession(user) {
    localStorage.setItem(SESSION_KEY, JSON.stringify(user));
  },

  getSession() {
    const raw = localStorage.getItem(SESSION_KEY);
    return raw ? JSON.parse(raw) : null;
  },

  clearSession() {
    localStorage.removeItem(SESSION_KEY);
  },

  isLoggedIn() {
    return !!this.getSession();
  },

  isManager() {
    const s = this.getSession();
    return s && s.role === 'manager';
  },

  isCollaborator() {
    const s = this.getSession();
    return s && s.role === 'collaborator';
  },
};
