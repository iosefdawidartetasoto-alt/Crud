// js/views/projects.js
import { api } from '../modules/api.js';
import { auth } from '../modules/auth.js';
import { showToast, showLoader, hideLoader, statusBadge, formatDate, openModal, closeModal, confirmDelete } from '../modules/ui.js';

const PAGE_SIZE = 6;
let allProjects = [];
let allUsers = [];
let filteredProjects = [];
let currentPage = 1;
let editingId = null;

export async function renderProjects() {
  const view = document.getElementById('projects-view');
  view.classList.add('active');

  showLoader();
  try {
    [allProjects, allUsers] = await Promise.all([api.getProjects(), api.getUsers()]);
    applyFilters();
    bindProjectEvents();
  } catch {
    showToast('Failed to load projects.', 'error');
  } finally {
    hideLoader();
  }
}

function applyFilters() {
  const user = auth.getSession();
  const search = document.getElementById('search-input')?.value.toLowerCase() || '';
  const statusFilter = document.getElementById('status-filter')?.value || '';

  let base = user.role === 'manager'
    ? allProjects
    : allProjects.filter(p => p.assignedTo === user.id);

  if (search) base = base.filter(p =>
    p.name.toLowerCase().includes(search) || p.description.toLowerCase().includes(search)
  );
  if (statusFilter) base = base.filter(p => p.status === statusFilter);

  filteredProjects = base;
  currentPage = 1;
  renderTable();
}

function renderTable() {
  const user = auth.getSession();
  const tbody = document.getElementById('projects-tbody');
  const isManager = user.role === 'manager';

  const start = (currentPage - 1) * PAGE_SIZE;
  const page = filteredProjects.slice(start, start + PAGE_SIZE);

  if (!page.length) {
    tbody.innerHTML = `<tr><td colspan="6"><div class="empty-state"><div class="empty-icon">🔍</div><p>No projects found.</p></div></td></tr>`;
    renderPagination();
    return;
  }

  const getUserName = (id) => {
    const u = allUsers.find(u => u.id === id);
    return u ? u.name : '—';
  };

  tbody.innerHTML = page.map(p => `
    <tr data-id="${p.id}">
      <td>
        <div class="project-name">${p.name}</div>
        <div class="project-desc">${p.description}</div>
      </td>
      <td>${statusBadge(p.status)}</td>
      <td>${getUserName(p.assignedTo)}</td>
      <td>${formatDate(p.createdAt)}</td>
      <td>
        <div class="actions-cell">
          <button class="btn-icon view-btn" data-id="${p.id}" title="View Details">👁</button>
          ${isManager ? `
            <button class="btn-icon edit-btn" data-id="${p.id}" title="Edit">✏️</button>
            <button class="btn-icon btn-danger delete-btn" data-id="${p.id}" title="Delete">🗑</button>
          ` : `
            ${p.assignedTo === user.id ? `<button class="btn-icon edit-status-btn" data-id="${p.id}" title="Update Status">🔄</button>` : ''}
          `}
        </div>
      </td>
    </tr>
  `).join('');

  renderPagination();
  bindTableEvents();
}

function renderPagination() {
  const container = document.getElementById('pagination');
  const total = Math.ceil(filteredProjects.length / PAGE_SIZE);
  if (total <= 1) { container.innerHTML = ''; return; }

  let html = `<button class="page-btn" id="prev-page" ${currentPage === 1 ? 'disabled' : ''}>‹</button>`;
  for (let i = 1; i <= total; i++) {
    html += `<button class="page-btn ${i === currentPage ? 'active' : ''}" data-page="${i}">${i}</button>`;
  }
  html += `<button class="page-btn" id="next-page" ${currentPage === total ? 'disabled' : ''}>›</button>`;
  container.innerHTML = html;

  container.querySelectorAll('[data-page]').forEach(btn => {
    btn.addEventListener('click', () => { currentPage = parseInt(btn.dataset.page); renderTable(); });
  });
  container.querySelector('#prev-page')?.addEventListener('click', () => { currentPage--; renderTable(); });
  container.querySelector('#next-page')?.addEventListener('click', () => { currentPage++; renderTable(); });
}

function bindTableEvents() {
  document.querySelectorAll('.view-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      import('./detail.js').then(m => {
        document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
        m.renderDetail(parseInt(btn.dataset.id));
      });
    });
  });

  document.querySelectorAll('.edit-btn').forEach(btn => {
    btn.addEventListener('click', (e) => { e.stopPropagation(); openEditModal(parseInt(btn.dataset.id)); });
  });

  document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      confirmDelete(async () => {
        showLoader();
        try {
          await api.deleteProject(parseInt(btn.dataset.id));
          allProjects = allProjects.filter(p => p.id !== parseInt(btn.dataset.id));
          applyFilters();
          showToast('Project deleted.', 'success');
        } catch {
          showToast('Failed to delete project.', 'error');
        } finally { hideLoader(); }
      });
    });
  });

  document.querySelectorAll('.edit-status-btn').forEach(btn => {
    btn.addEventListener('click', (e) => { e.stopPropagation(); openStatusModal(parseInt(btn.dataset.id)); });
  });
}

function bindProjectEvents() {
  const user = auth.getSession();

  document.getElementById('search-input')?.addEventListener('input', applyFilters);
  document.getElementById('status-filter')?.addEventListener('change', applyFilters);

  if (user.role === 'manager') {
    document.getElementById('new-project-btn')?.addEventListener('click', () => openCreateModal());
  }

  // Modal form submit
  document.getElementById('project-form').onsubmit = async (e) => {
    e.preventDefault();
    const name = document.getElementById('proj-name').value.trim();
    const description = document.getElementById('proj-desc').value.trim();
    const status = document.getElementById('proj-status').value;
    const assignedTo = parseInt(document.getElementById('proj-assigned').value);

    if (!name || !description || !assignedTo) {
      showToast('Please fill all required fields.', 'error');
      return;
    }

    showLoader();
    try {
      if (editingId) {
        const updated = await api.updateProject(editingId, { name, description, status, assignedTo });
        const idx = allProjects.findIndex(p => p.id === editingId);
        if (idx > -1) allProjects[idx] = updated;
        showToast('Project updated!', 'success');
      } else {
        const created = await api.createProject({ name, description, status, assignedTo, createdAt: new Date().toISOString().slice(0, 10) });
        allProjects.unshift(created);
        showToast('Project created!', 'success');
      }
      closeModal('project-modal');
      applyFilters();
    } catch {
      showToast('Failed to save project.', 'error');
    } finally { hideLoader(); }
  };

  // Status-only modal
  document.getElementById('status-form').onsubmit = async (e) => {
    e.preventDefault();
    const newStatus = document.getElementById('new-status').value;
    showLoader();
    try {
      const updated = await api.updateProject(editingId, { status: newStatus });
      const idx = allProjects.findIndex(p => p.id === editingId);
      if (idx > -1) allProjects[idx] = updated;
      closeModal('status-modal');
      applyFilters();
      showToast('Status updated!', 'success');
    } catch {
      showToast('Failed to update status.', 'error');
    } finally { hideLoader(); }
  };

  document.querySelectorAll('[data-close-modal]').forEach(btn => {
    btn.addEventListener('click', () => closeModal(btn.dataset.closeModal));
  });
}

function openCreateModal() {
  editingId = null;
  document.getElementById('modal-title').textContent = 'New Project';
  document.getElementById('project-form').reset();
  populateAssignedSelect();
  openModal('project-modal');
}

async function openEditModal(id) {
  editingId = id;
  document.getElementById('modal-title').textContent = 'Edit Project';
  const project = allProjects.find(p => p.id === id);
  if (!project) return;
  populateAssignedSelect(project.assignedTo);
  document.getElementById('proj-name').value = project.name;
  document.getElementById('proj-desc').value = project.description;
  document.getElementById('proj-status').value = project.status;
  openModal('project-modal');
}

function openStatusModal(id) {
  editingId = id;
  const project = allProjects.find(p => p.id === id);
  if (!project) return;
  document.getElementById('new-status').value = project.status;
  openModal('status-modal');
}

function populateAssignedSelect(selectedId = null) {
  const sel = document.getElementById('proj-assigned');
  const collaborators = allUsers.filter(u => u.role === 'collaborator');
  sel.innerHTML = `<option value="">Select collaborator...</option>` +
    collaborators.map(u => `<option value="${u.id}" ${u.id === selectedId ? 'selected' : ''}>${u.name}</option>`).join('');
}
