// js/views/detail.js
import { api } from '../modules/api.js';
import { auth } from '../modules/auth.js';
import { showToast, showLoader, hideLoader, statusBadge, formatDate } from '../modules/ui.js';
import { router } from '../modules/router.js';

export async function renderDetail(projectId) {
  const view = document.getElementById('detail-view');
  view.classList.add('active');

  showLoader();
  try {
    const [project, users] = await Promise.all([api.getProjectById(projectId), api.getUsers()]);
    const user = auth.getSession();
    const assignee = users.find(u => u.id === project.assignedTo);
    const isManager = user.role === 'manager';
    const isOwner = user.id === project.assignedTo;

    document.getElementById('detail-content').innerHTML = `
      <div class="detail-card">
        <div class="detail-header">
          <div>
            <h2>${project.name}</h2>
            <div style="margin-top:8px">${statusBadge(project.status)}</div>
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            ${isManager ? `
              <button class="btn btn-secondary" id="edit-detail-btn">✏️ Edit</button>
              <button class="btn btn-danger" id="delete-detail-btn">🗑 Delete</button>
            ` : isOwner ? `
              <button class="btn btn-secondary" id="update-status-btn">🔄 Update Status</button>
            ` : ''}
            <button class="btn btn-secondary" id="back-btn">← Back</button>
          </div>
        </div>
        <p style="color:var(--text-muted);line-height:1.7">${project.description}</p>
        <div class="detail-meta">
          <div class="meta-item">
            <label>Assigned To</label>
            <span>${assignee ? assignee.name : '—'}</span>
          </div>
          <div class="meta-item">
            <label>Status</label>
            <span>${project.status}</span>
          </div>
          <div class="meta-item">
            <label>Created</label>
            <span>${formatDate(project.createdAt)}</span>
          </div>
          <div class="meta-item">
            <label>Project ID</label>
            <span>#${project.id}</span>
          </div>
        </div>
      </div>
    `;

    document.getElementById('back-btn').addEventListener('click', () => router.navigate('projects'));

    if (isManager) {
      document.getElementById('edit-detail-btn').addEventListener('click', () => {
        router.navigate('projects');
        setTimeout(() => {
          document.querySelector(`.edit-btn[data-id="${project.id}"]`)?.click();
        }, 100);
      });
      document.getElementById('delete-detail-btn').addEventListener('click', async () => {
        if (!confirm('Delete this project?')) return;
        showLoader();
        try {
          await api.deleteProject(project.id);
          showToast('Project deleted.', 'success');
          router.navigate('projects');
        } catch { showToast('Failed to delete.', 'error'); }
        finally { hideLoader(); }
      });
    }

    if (!isManager && isOwner) {
      document.getElementById('update-status-btn').addEventListener('click', () => {
        showStatusForm(project);
      });
    }
  } catch {
    showToast('Failed to load project.', 'error');
    document.getElementById('detail-content').innerHTML = `<div class="empty-state"><p>Project not found.</p></div>`;
  } finally {
    hideLoader();
  }
}

function showStatusForm(project) {
  const statusOptions = ['Pending', 'In Progress', 'Completed', 'Cancelled'];
  const select = document.createElement('select');
  select.className = 'filter-select';
  select.style.marginTop = '12px';
  statusOptions.forEach(s => {
    const opt = document.createElement('option');
    opt.value = s; opt.textContent = s;
    if (s === project.status) opt.selected = true;
    select.appendChild(opt);
  });

  const btn = document.createElement('button');
  btn.className = 'btn btn-success';
  btn.style.marginLeft = '8px';
  btn.textContent = 'Save';

  const wrapper = document.createElement('div');
  wrapper.style.marginTop = '16px';
  wrapper.appendChild(select);
  wrapper.appendChild(btn);

  document.querySelector('.detail-card').appendChild(wrapper);

  btn.addEventListener('click', async () => {
    showLoader();
    try {
      await api.updateProject(project.id, { status: select.value });
      showToast('Status updated!', 'success');
      renderDetail(project.id);
    } catch { showToast('Update failed.', 'error'); }
    finally { hideLoader(); }
  });
}
