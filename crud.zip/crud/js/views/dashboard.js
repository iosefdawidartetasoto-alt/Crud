// js/views/dashboard.js
import { api } from '../modules/api.js';
import { auth } from '../modules/auth.js';
import { showToast, hideLoader, showLoader, statusBadge, formatDate } from '../modules/ui.js';

export async function renderDashboard() {
  const view = document.getElementById('dashboard-view');
  view.classList.add('active');
  const user = auth.getSession();

  showLoader();
  try {
    const projects = await api.getProjects();
    const users = await api.getUsers();

    const myProjects = user.role === 'manager'
      ? projects
      : projects.filter(p => p.assignedTo === user.id);

    renderStats(myProjects, user.role);
    renderRecentProjects(myProjects, users, user.role);
  } catch {
    showToast('Failed to load dashboard data.', 'error');
  } finally {
    hideLoader();
  }
}

function renderStats(projects, role) {
  const total = projects.length;
  const active = projects.filter(p => p.status === 'In Progress').length;
  const completed = projects.filter(p => p.status === 'Completed').length;
  const pending = projects.filter(p => p.status === 'Pending').length;

  const el = document.getElementById('dashboard-stats');

  if (role === 'manager') {
    el.innerHTML = `
      <div class="stat-card">
        <div class="stat-icon" style="background:rgba(108,99,255,0.15)">📁</div>
        <div class="stat-value">${total}</div>
        <div class="stat-label">Total Projects</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon" style="background:rgba(59,130,246,0.15)">⚡</div>
        <div class="stat-value">${active}</div>
        <div class="stat-label">In Progress</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon" style="background:rgba(34,197,94,0.15)">✅</div>
        <div class="stat-value">${completed}</div>
        <div class="stat-label">Completed</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon" style="background:rgba(245,158,11,0.15)">⏳</div>
        <div class="stat-value">${pending}</div>
        <div class="stat-label">Pending</div>
      </div>
    `;
  } else {
    el.innerHTML = `
      <div class="stat-card">
        <div class="stat-icon" style="background:rgba(108,99,255,0.15)">📋</div>
        <div class="stat-value">${total}</div>
        <div class="stat-label">My Projects</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon" style="background:rgba(59,130,246,0.15)">⚡</div>
        <div class="stat-value">${active}</div>
        <div class="stat-label">In Progress</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon" style="background:rgba(34,197,94,0.15)">✅</div>
        <div class="stat-value">${completed}</div>
        <div class="stat-label">Completed</div>
      </div>
    `;
  }
}

function renderRecentProjects(projects, users, role) {
  const container = document.getElementById('recent-projects');
  const recent = [...projects].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 5);

  if (!recent.length) {
    container.innerHTML = `<div class="empty-state"><div class="empty-icon">📭</div><p>No projects yet.</p></div>`;
    return;
  }

  const getUserName = (id) => {
    const u = users.find(u => u.id === id);
    return u ? u.name : 'Unassigned';
  };

  container.innerHTML = `
    <table class="projects-table">
      <thead>
        <tr>
          <th>Project</th>
          <th>Status</th>
          <th>Assigned To</th>
          <th>Created</th>
        </tr>
      </thead>
      <tbody>
        ${recent.map(p => `
          <tr data-id="${p.id}">
            <td>
              <div class="project-name">${p.name}</div>
              <div class="project-desc">${p.description}</div>
            </td>
            <td>${statusBadge(p.status)}</td>
            <td>${getUserName(p.assignedTo)}</td>
            <td>${formatDate(p.createdAt)}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;

  // Row click -> detail
  container.querySelectorAll('tr[data-id]').forEach(row => {
    row.addEventListener('click', () => {
      import('./detail.js').then(m => {
        document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
        m.renderDetail(parseInt(row.dataset.id));
      });
    });
  });
}
