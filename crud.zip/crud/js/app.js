// js/app.js
import { router } from './modules/router.js';
import { auth } from './modules/auth.js';
import { showToast } from './modules/ui.js';
import { renderLogin } from './views/login.js';
import { renderDashboard } from './views/dashboard.js';
import { renderProjects } from './views/projects.js';
import { renderDetail } from './views/detail.js';

// === THEME ===
const savedTheme = localStorage.getItem('theme') || 'dark';
document.documentElement.setAttribute('data-theme', savedTheme);

document.getElementById('theme-toggle').addEventListener('click', () => {
  const current = document.documentElement.getAttribute('data-theme');
  const next = current === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem('theme', next);
  document.getElementById('theme-toggle').textContent = next === 'dark' ? '☀️' : '🌙';
});

// Set initial theme icon
document.getElementById('theme-toggle').textContent = savedTheme === 'dark' ? '☀️' : '🌙';

// === NAVBAR ===
function updateNavbar() {
  const user = auth.getSession();
  const navbar = document.getElementById('app-navbar');
  if (!user) { navbar.style.display = 'none'; return; }
  navbar.style.display = 'flex';

  const initials = user.name.split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase();
  document.getElementById('nav-avatar').textContent = initials;
  document.getElementById('nav-username').textContent = user.name;
  document.getElementById('nav-role').textContent = user.role;
  document.getElementById('nav-role-badge').textContent = user.role;
  document.getElementById('nav-role-badge').className = `role-badge ${user.role}`;

  // Show/hide nav links based on role
  const projectsLink = document.getElementById('nav-projects');
  if (projectsLink) projectsLink.style.display = 'flex';
}

// === NAV LINKS ===
document.getElementById('nav-dashboard').addEventListener('click', (e) => {
  e.preventDefault();
  router.navigate('dashboard');
});
document.getElementById('nav-projects').addEventListener('click', (e) => {
  e.preventDefault();
  router.navigate('projects');
});
document.getElementById('logout-btn').addEventListener('click', () => {
  auth.clearSession();
  showToast('You have been logged out.', 'info');
  router.navigate('login');
});

// === REGISTER ROUTES ===
router.register('login', () => {
  updateNavbar();
  renderLogin();
});

router.register('dashboard', () => {
  updateNavbar();
  renderDashboard();
});

router.register('projects', () => {
  updateNavbar();
  renderProjects();
});

router.register('detail', ({ id }) => {
  updateNavbar();
  renderDetail(id);
});

// === INIT ===
router.init();
